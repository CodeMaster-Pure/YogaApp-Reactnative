import { StyleSheet } from 'react-native'
import Colors from 'App/Theme/Colors'
import ApplicationStyles from 'App/Theme/ApplicationStyles'
import { white } from 'ansi-colors'

export default StyleSheet.create({

})
