import React from 'react'
import { Text, View } from 'react-native'
import styles from './StatisticalScreenStyle'

export default class StatisticalScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        {/* You will probably want to insert your logo here */}
        <Text>StatisticalScreen</Text>
      </View>
    )
  }
}
