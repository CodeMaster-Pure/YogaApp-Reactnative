import React from 'react'
import { Text, View } from 'react-native'
import styles from './MonthlySailScreenStyle'

export default class MonthlySailScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        
        
      </View>
    )
  }
}
