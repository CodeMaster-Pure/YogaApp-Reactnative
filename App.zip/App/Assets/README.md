This directory contains all the assets files (i.e. images, audio files or videos...) used by the application.
