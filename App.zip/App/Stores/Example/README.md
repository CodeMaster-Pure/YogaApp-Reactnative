This directory contains an example of a store and all its files.

You can safely delete it after removing it from [App/Stores/index.js](../index.js).
